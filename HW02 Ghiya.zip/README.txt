SML_HWK1

Name: Sagar Ghiya

-> Please open the .py file in jupyter notebook, spyder or anywhere else where it supports .py file.
-> Run the code in a normal way to get the outputs.
-> Make sure to change the working directory at the begining of the program.
